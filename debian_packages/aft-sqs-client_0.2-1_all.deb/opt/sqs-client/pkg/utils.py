import os

import boto3


def get_or_default(env_var_name, default_value, is_list=False):
    env_var = os.environ.get(env_var_name)
    if env_var is not None and len(env_var) > 0:
        if is_list:
            return env_var.split(',')
        else:
            return env_var
    else:
        return default_value


def get_client(region, service):
    session = boto3.session.Session()
    client = session.client(
        service_name=service,
        region_name=region)
    return client
