from argparse import Namespace
import os
import re
import yaml

import boto3


STDOUT_DEST = "stdout"


def get_or_default(env_var_name, default_value, is_list=False):
    env_var = os.environ.get(env_var_name)
    if env_var is not None and len(env_var) > 0:
        if is_list:
            return env_var.split(',')
        else:
            return env_var
    else:
        return default_value


def get_client(region, service):
    session = boto3.session.Session()
    client = session.client(
        service_name=service,
        region_name=region)
    return client


def make_namespace(queue_conf, base: Namespace):
    options = Namespace(**vars(base))
    update_dict = vars(options)
    update_dict["queue"] = queue_conf["queue"]
    update_dict["s3_event_payload"] = queue_conf["s3-event-payload"]
    update_dict["s3_delete"] = queue_conf["s3-delete"]
    destination = queue_conf.get("destination", STDOUT_DEST)
    update_dict["destination"] = destination
    return options


def parse_config(path, tag="!ENV"):
    """Parse YAML and load in env variables.

    Default behavior: Replace "!ENV ${VAR_NAME}" with the environment
        variable VAR_NAME.

    E.g
    queue_name:
        queue: !ENV ${QUEUE_URL}
        destination: !ENV ${DEST_URL}
        some_path: !ENV ${ROOT_FOLDER}/${SUB_FOLDER} 

    Args:
        path (str): Path to .yml file
        tag (str, optional): Tag to identify environment variables.
            Defaults to "!ENV".
    """
    pattern = re.compile('.*?\${(\w+)}.*?') # finds all instances of ${<WORD>} in node
    loader = yaml.SafeLoader
    loader.add_implicit_resolver(tag, pattern, None)

    def env_variable_constructor(loader: yaml.Loader, node):
        """Replace tagged node with environment variables.

        Args:
            loader (yaml.Loader): Loader
            node: Current node in yaml
        """
        value = loader.construct_scalar(node)
        match = pattern.findall(value)
        if not match:
            return value
        
        full_value = value
        for m in match:
            full_value = full_value.replace(
                f'${{{m}}}',
                os.environ.get(m, "UNKNOWN"),
            )
        return full_value

    loader.add_constructor(tag, env_variable_constructor)
    with open(path, 'r') as f:
        return yaml.load(f, Loader=loader)
