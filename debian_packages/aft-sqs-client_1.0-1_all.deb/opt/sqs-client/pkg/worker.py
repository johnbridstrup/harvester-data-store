import json
import logging
import os
import threading
from http import HTTPStatus

import requests

from pkg.metrics import Metrics
from pkg.utils import STDOUT_DEST, get_or_default, get_client

DEFAULT_AWS_REGION = 'us-west-1'


class Worker(threading.Thread):
    def __init__(self, options, sqs_client=None, s3_client=None):
        threading.Thread.__init__(self, daemon=True, target=self._work)
        self._stopper = threading.Event()
        self.sqs = options.queue
        self.destination = options.destination
        self.s3_event_payload = options.s3_event_payload
        self.s3_delete = options.s3_delete
        self.delete = options.delete
        self.sqs_visibility_timeout = 10
        self.sqs_wait_time_seconds = 20
        self.headers = options.headers

        if sqs_client is not None:
            self.sqs_client = sqs_client
        else:
            self.sqs_client = get_client(get_or_default("AWS_REGION", DEFAULT_AWS_REGION), "sqs")

        if self.s3_event_payload:
            if s3_client is not None:
                self.s3_client = s3_client
            else:
                self.s3_client = get_client(get_or_default("AWS_REGION", DEFAULT_AWS_REGION), "s3")

    def _url_destination(self, message):
        resp = requests.post(self.destination, timeout=2, json=message, headers=self.headers)
        resp.raise_for_status()
        logging.info("Message correctly delivered to {dest}".format(dest=self.destination))
        
        return resp

    def _stdout_destination(self, message):
        for key in message:
            logging.info("{key}:{value}".format(key=key, value=message.get(key)))

    def _send_message(self, message):
        if STDOUT_DEST in self.destination:
            return self._stdout_destination(message)
        if 'http' in self.destination:
            return self._url_destination(message)
        error_msg = 'Error can\'t find the right destination for the message, got: {dest}'.format(dest=self.destination)
        raise Exception(error_msg)

    def _get_s3_payload(self, bucket, key):
        filename = "/tmp/" + key.split("/")[-1]
        try:
            self.s3_client.download_file(bucket, key, filename)
            logging.debug("File {key} successfully downloaded from {bucket}".format(key=key, bucket=bucket))
            with open(filename) as tmp_file:
                return json.load(tmp_file)
        except ValueError as e:
            msg = "Error cannot load json from file {file} {err}".format(file=filename, err=str(e))
            logging.error(msg)
        except Exception as e:
            raise e
        finally:
            if os.path.exists(filename):
                os.remove(filename)

    def _process_s3_events(self, messages):
        resp = list()
        for message in messages:
            body = json.loads(message.get('Body'))
            if body and body.get('Records'):
                for record in body.get('Records'):
                    if record.get('s3'):
                        bucket_name = record.get('s3').get('bucket').get('name')
                        object_key = record.get('s3').get('object').get('key')
                        if bucket_name and object_key:
                            payload = self._get_s3_payload(bucket_name, object_key)
                            if payload:
                                # attaching the ReceiptHandle of the original message
                                # so we can delete the msg from the queue
                                payload['ReceiptHandle'] = message.get('ReceiptHandle')
                                # attaching S3Path so we can delete the file from S3
                                payload['S3Path'] = {'bucket': bucket_name, 'key': object_key}
                                resp.append(payload)
        return resp

    def _fetch_messages(self):
        logging.debug("Fetching messages from SQS queue")
        response = self.sqs_client.receive_message(
            QueueUrl=self.sqs,
            MaxNumberOfMessages=10,
            VisibilityTimeout=self.sqs_visibility_timeout,
            WaitTimeSeconds=self.sqs_wait_time_seconds)

        status = response.get('ResponseMetadata').get('HTTPStatusCode')
        if status != HTTPStatus.OK:
            error_msg = 'Error retrieving messages from SQS {error_code}'.format(error_code=status)
            raise Exception(error_msg)

        messages = response.get('Messages')
        if not messages:
            return []

        if self.s3_event_payload:
            return self._process_s3_events(messages)
        else:
            return messages

    def _delete_message(self, msg_res_handler):
        logging.debug("Deleting message from the queue")
        resp = self.sqs_client.delete_message(QueueUrl=self.sqs,
                                              ReceiptHandle=msg_res_handler)
        status = resp.get('ResponseMetadata').get('HTTPStatusCode')
        if status != HTTPStatus.OK:
            error_msg = 'Error deleting messages from SQS {error_code}'.format(error_code=status)
            raise Exception(error_msg)
        logging.info("Message {msg_id} successfully deleted from the queue".format(msg_id=msg_res_handler))

    def _delete_s3_files(self, s3_path):
        logging.debug("Deleting object from S3 bucket")
        self.s3_client.delete_object(Bucket=s3_path.get('bucket'), Key=s3_path.get('key'))
        logging.info("Object {obj} successfully deleted from {bucket}".format(obj=s3_path.get('key'),
                                                                              bucket=s3_path.get('bucket')))

    def _work(self):
        queue_name = self.sqs.split('/')[-1]
        logging.info(f"Start fetching messages from SQS queue: {queue_name}")
        while not self._stopper.is_set():
            try:
                messages = self._fetch_messages()
                for message in messages:
                    Metrics.inc_sqs_fetched_messages()
                    msg_res_handler = message.get('ReceiptHandle')
                    del message['ReceiptHandle']
                    s3_path = message.get('S3Path')
                    if s3_path is not None:
                        del message['S3Path']
                    self._send_message(message)
                    Metrics.inc_dest_delivered_messages()

                    if self.delete:
                        self._delete_message(msg_res_handler)
                        Metrics.inc_sqs_deleted_messages()

                    if self.s3_delete and self.s3_client is not None and s3_path is not None:
                        self._delete_s3_files(s3_path)
                        Metrics.inc_s3_deleted_files()

            except Exception as e:
                logging.error(e)
            self._stopper.wait(1)

    def stop(self):
        self._stopper.set()
