import argparse
import enum
import json
import logging
import signal
import sys
import yaml

from prometheus_client import start_http_server

from pkg.worker import Worker
from pkg.utils import STDOUT_DEST, make_namespace, parse_config

# logging configuration
logFormatter = logging.Formatter('%(message)s')
consoleHandler = logging.StreamHandler()
consoleHandler.setFormatter(logFormatter)
logging.getLogger().addHandler(consoleHandler)

threads = list()


class SubParsers(enum.Enum):
    DIRECT = "direct"
    FROM_YAML = "from-yaml"


def handler_stop_signals(signum, frame):
    global threads
    for t in threads:
        t.stop()
    sys.exit(0)


def setup_options():
    parser = argparse.ArgumentParser(
        description="AWS SQS client")
    subparsers = parser.add_subparsers(help="Client configuration build options", dest="subparser")
    direct = subparsers.add_parser(SubParsers.DIRECT.value, description="Build client from command line options")
    from_yaml = subparsers.add_parser(SubParsers.FROM_YAML.value, aliases=["yml"], description="Build multiple clients from yaml")
    from_yaml.add_argument("--yml", required=True, help="YAML config file")
    direct.add_argument('--queue', required=True, help='SQS URL')
    direct.add_argument('--destination', required=False, default=STDOUT_DEST,
                        help='''
                            Where to send the SQS message, the default destination is stdout.
                            If an URL is specified, the SQS message will be sent using a POST request.
                            Refer to the requests.post package documentation for more info.
                            ''')
    direct.add_argument('--s3-event-payload', action="store_true", required=False, default=False,
                        help="With S3 events in SQS, download the S3 file and send the payload to destination.")
    direct.add_argument('--s3-delete', action="store_true", required=False, default=False,
                        help="Delete s3 content after processing")
    parser.add_argument('--delete', action="store_true", required=False, default=False,
                        help="Delete messages after processing")
    parser.add_argument('-v', '--verbose', action="store_true", required=False, default=False, help="Enable debug logs")
    parser.add_argument(
        '--headers', 
        required=False, 
        type=json.loads, 
        help='A dictionary of headers and values. E.g. --headers {"Accept": "application/json"}')
    parser.add_argument('--prom-port', required=False, default=9104, help='Prometheus metrics exporter bind port', type=int)
    options = parser.parse_args()

    if options.verbose:
        logging.getLogger().level = logging.DEBUG
    else:
        logging.getLogger().level = logging.INFO

    return options


def main():
    options = setup_options()
    start_http_server(options.prom_port)
    logging.info("Metrics endpoint successfully started")

    global threads

    if options.subparser == SubParsers.DIRECT.value:
        worker = Worker(options)
        threads.append(worker)
        worker.start()
    elif options.subparser == SubParsers.FROM_YAML.value:
        config = parse_config(options.yml)
        for queue_conf in config.values():
            opts = make_namespace(queue_conf, options)
            worker = Worker(opts)
            threads.append(worker)
            worker.start()

    for t in threads:
        t.join()


if __name__ == '__main__':
    signal.signal(signal.SIGINT, handler_stop_signals)
    signal.signal(signal.SIGTERM, handler_stop_signals)
    main()
