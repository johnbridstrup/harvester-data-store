from prometheus_client import Counter

SQS_FETCHED_MSG = Counter(
    'sqs_fetched_messages',
    'number of sqs messages fetched from the queue'
)

SQS_DELETED_MSG = Counter(
    'sqs_deleted_messages',
    'number of messages delete from the queue'
)

DEST_DELIVERED_MSG = Counter(
    'dest_delivered_messages',
    'number of messages delivered to destination'
)

S3_DELETED_FILES = Counter(
    's3_deleted_files',
    'number of file delete from S3'
)


class Metrics:
    @staticmethod
    def inc_sqs_fetched_messages():
        SQS_FETCHED_MSG.inc()

    @staticmethod
    def inc_sqs_deleted_messages():
        SQS_DELETED_MSG.inc()

    @staticmethod
    def inc_dest_delivered_messages():
        DEST_DELIVERED_MSG.inc()

    @staticmethod
    def inc_s3_deleted_files():
        S3_DELETED_FILES.inc()
